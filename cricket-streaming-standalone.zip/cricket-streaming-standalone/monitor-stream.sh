#!/bin/bash
echo "📊 Cricket Tournament Stream Monitor"
echo "==================================="
echo "Monitoring stream health in real-time..."
echo "Press Ctrl+C to stop"
echo ""
node monitor.js

#!/bin/bash
echo "🧪 Testing Cricket Streaming System"
echo "==================================="
node test-stream.js
